<?php
class Template {
	protected $ci;
	function __construct(){
		$this->ci =&get_instance();
	}

	function admin($template, $data=null)
	{
		$data['content']=$this->ci->load->view($template, $data, TRUE);
		$data['source']=$this->ci->load->view('admin/source',$data, TRUE);
		$this->ci->load->view('admin/dashboard', $data);
	}

	function login($template, $data=null)
	{
		$data['content']=$this->ci->load->view($template, $data, TRUE);
		$data['source']=$this->ci->load->view('login/source',$data, TRUE);
		$this->ci->load->view('login/master', $data);
	}
	
}