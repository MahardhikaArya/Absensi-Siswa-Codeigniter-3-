<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                <h2 class="title-1">Daftar Pengabsen di SD Anda</h2>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php $kelas = $this->session->userdata('kelas');?>
                                <h2 class="title-1"></h2><hr>
                                <div class="table-responsive table--no-card m-b-40">
                                    <?php 
                                        if ($this->session->flashdata('berhasil')) {
                                            echo "<div class='sufee-alert alert with-close alert-success alert-dismissible fade show'>";
                                            echo "<span class='badge badge-pill badge-success'>Success</span>";
                                            echo $this->session->flashdata('berhasil');
                                            echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
                                            echo "<span aria-hidden='true'>&times;</span>";
                                            echo "</button>";
                                            echo "</div>";
                                        }

                                     ?>                                             
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nama</th>
                                                <th>Username</th>
                                                <th>Kelas</th>
                                                <th>Level User</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i=1; foreach($admin->result() as $key):?>
                                        <tr>
                                            <td><?= $i++;?></td>
                                            <td><?= $key->NamaLengkap;?></td>
                                            <td><?= $key->username;?></td>
                                            <td><?= $key->kelas;?></td>
                                            <td><?= $key->level;?></td>
                                            <td>
                                                <a href="<?= base_url('index.php');?>/Kelas/Detail_kelas/<?= $key->kelas;?>">
                                                    <button class="btn btn-primary">Lihat Detail</button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                       </div>

                                               <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                <h2 class="title-1">Daftar Admin Aplikasi Abzens</h2>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                                      <i class="fa fa-plus"></i> Tambah Admin
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php $kelas = $this->session->userdata('kelas');?>
                                <h2 class="title-1"></h2><hr>
                                <div class="table-responsive table--no-card m-b-40">
                                    <?php 
                                        if ($this->session->flashdata('berhasil')) {
                                            echo "<div class='sufee-alert alert with-close alert-success alert-dismissible fade show'>";
                                            echo "<span class='badge badge-pill badge-success'>Success</span>";
                                            echo $this->session->flashdata('berhasil');
                                            echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
                                            echo "<span aria-hidden='true'>&times;</span>";
                                            echo "</button>";
                                            echo "</div>";
                                        }

                                     ?>                                             
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nama</th>
                                                <th>Username</th>
                                                <th>Kelas</th>
                                                <th>Level User</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i=1; foreach($admins->result() as $key):?>
                                        <tr>
                                            <td><?= $i++;?></td>
                                            <td><?= $key->NamaLengkap;?></td>
                                            <td><?= $key->username;?></td>
                                            <td><?= $key->kelas;?></td>
                                            <td><?= $key->level;?></td>
                                        </tr>
                                        <?php endforeach; ?>    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        
                       </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade bd-example-modal-lg" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Tambah Siswa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form  method="post" action="<?= base_url('index.php')?>/Siswa/insert_siswa" role="form" enctype="multipart/form-data" class="col-md-12">
                      <div class="form-group col-md-6">
                        <label for="formGroupExampleInput">Nama</label>
                        <input type="text" required="" name="nama" class="form-control" placeholder="...">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="formGroupExampleInput">NIS</label>
                        <input type="number" required="" name="nis" class="form-control" placeholder="...">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="formGroupExampleInput">Kelas</label>
                        <select class="form-control" name="kelas" required="">
                            <?php foreach ($kelas as $k) :?>
                                <option value="<?= $k->nama;?>"><?= $k->id;?></option>
                            <?php endforeach; ?>
                        </select>
                      <div class="form-group col-md-6">
                        <label for="formGroupExampleInput">Telepon</label>
                        <input type="number" name="telepon" required="" class="form-control" placeholder="08...">
                      </div>
                      <div class="form-group col-md-12">
                        <label for="formGroupExampleInput2">Alamat</label>
                        <input type="text" class="form-control" name="alamat" placeholder="Jl...." required="">
                      </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save data</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            <!-- END MAIN CONTENT-->