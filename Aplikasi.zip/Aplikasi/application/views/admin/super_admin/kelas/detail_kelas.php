
<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                <h2 class="title-1">Detail Siswa Kelas <?= $this->uri->segment(3);?></h2>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                                      <i class="fa fa-plus"></i> Tambah Data
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php $kelas = $this->session->userdata('kelas');?>
                                <h2 class="title-1"></h2><hr>
<!--                                 <style type="text/css">
                                    .tableFixHead{overflow-y: auto;height: 450px;}
                                    .tableFixHead thead th{position: sticky;top: 0;}
                                </style>                                
 -->                                <div class="table-responsive table--no-card m-b-40 tableFixHead">
                                    <?php 
                                        if ($this->session->flashdata('berhasil')) {
                                            echo "<div class='sufee-alert alert with-close alert-success alert-dismissible fade show'>";
                                            echo "<span class='badge badge-pill badge-success'>Success</span>";
                                            echo $this->session->flashdata('berhasil');
                                            echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
                                            echo "<span aria-hidden='true'>&times;</span>";
                                            echo "</button>";
                                            echo "</div>";
                                        }

                                     ?>                                             
                                    <table class="table table-borderless table-striped table-earning tableFixHead myTable" id="myTable">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nama</th>
                                                <th>Aksi</th>                                                
                                                <th>Alamat</th>
                                                <th>Telepon</th>
                                                <th>nis</th>
                                                <th>nisn</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $i=1; foreach($admin->result() as $key):?>
                                        <tr>
                                            <td><?= $i++;?></td>
                                            <td><?= $key->nama?></td>
                                            <td>
                                                <a href="<?= base_url('index.php');?>/Siswa/Detail_siswa/<?= $key->id;?>">
                                                    <button class="btn btn-primary"><i class="fa fa-eye"></i> Lihat Detail</button>
                                                </a>
                                            </td>
                                            <td><?= $key->alamat;?></td>
                                            <td><?= $key->telepon;?></td>
                                            <td><?= $key->nis;?></td>
                                            <td><?= $key->nisn;?></td>
                                        </tr>
                                        <?php endforeach; ?>    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                       </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->