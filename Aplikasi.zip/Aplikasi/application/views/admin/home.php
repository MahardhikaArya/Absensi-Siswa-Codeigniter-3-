<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                     <p>Tahun Ajaran <?php foreach ($tahun as $key): ?>
                                        <?php echo $key->nama; ?>
                                    <?php endforeach ?></p>
                                    
                                    <?php $data = $this->session->userdata('nama'); ?>
                                      <?php 
                                        $date1 = date('Y');
                                        $date2 = date('Y');
                                     ?>
                                    <h1 class="">Hallo <?= $data;  ?></h1>
                                    <p>Tanggal : <?= date('d - m - Y');?></p>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <h2 class="title-1 m-b-25">Absensi Hari ini</h2>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>NIS</th>
                                                <th>Nama</th>
                                                <th>Keterangan</th>
                                                <th>Catatan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php if ($hari_ini->num_rows() > 0): ?>
                                        <?php foreach($hari_ini->result() as $key):?>
                                        <tr>
                                            <td><?= $key->nis;  ?></td>
                                            <td><?= $key->nama;  ?></td>
                                            <td><?= $key->keterangan;  ?></td>
                                            <td><?= $key->catatan;  ?></td>
                                        </tr>
                                        <?php endforeach; ?>    
                                        <?php endif ?>
                                        <?php if ($hari_ini->num_rows() == 0): ?>
                                            <tr>
                                                <td colspan="5" class="text-center text-success"><b>Absensi Belum Dilaksanakan / Hari ini Nihil</b></td>
                                            </tr>
                                        <?php endif ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php 
                                        if ($this->session->flashdata('berhasil')) {
                                            echo "<div class='sufee-alert alert with-close alert-success alert-dismissible fade show'>";
                                            echo "<span class='badge badge-pill badge-success'>Success</span>";
                                            echo $this->session->flashdata('berhasil');
                                            echo "<a href='Absensi'>Lihat Absensi Selengkapnya...</a>";
                                            echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>";
                                            echo "<span aria-hidden='true'>&times;</span>";
                                            echo "</button>";
                                            echo "</div>";
                                        }

                                     ?>         
                                <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModalCenter">
                                    Tambah Absensi
                                </button>
                                <h2 class="title-1 m-b-25">Siswa Kelas <?= $this->session->userdata('kelas'); ?></h2>
                                <style type="text/css">
                                    .tableFixHead{overflow-y: auto;height: 500px;}
                                    .tableFixHead thead th{position: sticky;top: 0;}
                                </style>
                                <div class="table-responsive table--no-card m-b-40 tableFixHead">
                                    <table class="table table-borderless table-striped table-earning tableFixHead">
                                        <thead>
                                            <tr>
                                                <th>Nama</th>
                                                <th>NIS</th>
                                                <th>Kelas</th>
                                                <th>Alamat</th>
                                                <th>Telepon</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($siswas->result() as $key):?>
                                            <tr>
                                                <td><?= $key->nama;  ?></td>
                                                <td><?= $key->nis;  ?></td>
                                                <td><?= $key->kelas;  ?></td>
                                                <td><?= $key->alamat;  ?></td>
                                                <td><?= $key->telepon;  ?></td>
                                            </tr>
                                        <?php endforeach; ?>    
                                        </tbody>
                                    </table>                             
                                </div>
                            </div>

                            
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- modal medium -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true" style="margin-top: 10%;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="">Tambah Absensi</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <form action="<?= base_url('index.php');?>/dashboard/tambah" method="post" id="form">
                        <div class="row col-lg-12 col-md-12 col-sm-12">
                            <?php $tanggal = date('Y-m-d'); ?>
                            
                            <input type="text" name="id" hidden="">
                            <input type="text" name="nis" hidden="">

                            <?php foreach ($semester as $k): ?>
                            <input type="text" name="semester" value="<?= $k->nama;?>" hidden="">
                            <?php endforeach ?>

                            <input type="date" name="tanggal" value="<?= $tanggal;  ?>" hidden="">

                            <?php $kelas = $this->session->userdata('kelas');?>
                            <input type="text" name="kelas" value="<?= $kelas;?>" hidden="">

                            <div class="form-group col-lg-6 col-md-4 col-sm-12">
                                <label class="control-label mb-1">Nama</label>
                                <select class="form-control" name="nama" required="">
                                    <?php foreach ($siswas->result() as $key) :?>
                                    <option value="<?= $key->nama;?>"><?= $key->nama;?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group col-lg-6 col-md-4 col-sm-12">
                                <label class="control-label mb-1">Keterangan</label>
                                <select class="form-control" name="keterangan" required="">
                                    <option value="sakit">Sakit</option>
                                    <option value="ijin">Ijin</option>
                                    <option value="alpha">Alpha</option>
                                    <option value="dispen">Dispen</option>
                                </select>
                            </div>

                            <div class="form-group col-lg-6 col-md-4 col-sm-12" hidden="">
                                <label class="control-label mb-1">Tahun Ajaran</label>
                                <select class="form-control" name="tahun_ajaran" required="">
                                    <?php foreach ($tahun_ajaran as $key): ?>
                                        <option value="<?php echo $key->nama; ?>"><?php echo $key->nama; ?></option>    
                                    <?php endforeach ?>
                                    
                                </select>
                            </div>


                            <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                <label class="control-label mb-1">Catatan</label>
                                <input type="text" name="catatan" class="form-control">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-lg btn-info btn-block">
                            <i class="fa fa-save"></i>&nbsp;
                            <span id="payment-button-amount">Simpan Absensi</span>
                        </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end modal medium -->
            <!-- END MAIN CONTENT-->