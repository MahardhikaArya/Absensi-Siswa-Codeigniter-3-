<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12 col-lg-12">
                  <div class="card">
                     <div class="card-header">
                      <h5><i class="fa fa-gear"></i>Edit Absensi</h5>
                  </div>
                  <div class="card-body">

               <form action="<?= base_url('index.php');?>/Absensi/proses_edit/<?php echo $id;?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label>Nama Siswa</label>
                  <select name="nama" class="form-control">
                    <option value="<?php echo $nama;?>"><?php echo $nama;?></option>
                  </select>                  
                </div>

                <div class="form-group">
                  <label class="control-label mb-1">Keterangan</label>
                  <select class="form-control" name="keterangan" required="">
                      <option value="sakit">Sakit</option>
                      <option value="ijin">Ijin</option>
                      <option value="alpha">Alpha</option>
                      <option value="dispen">Dispen</option>
                  </select>
                </div>

                <div class="form-group col-lg-12 col-md-12 col-sm-12">
                    <label class="control-label mb-1">Catatan</label>
                    <textarea class="form-control" name="catatan"><?php echo $catatan; ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary" onclick="return confirm('Konfirmasi Pembaruan data');" value="Submit">Perbarui Data</button>

                <button class="btn btn-warning">Kembali</button>
               </form>
        </div>
    </div>    
</div>
</div>
</div>
</div>
</div>
</div>