<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <div class="col-md-12 col-sm-12 col-lg-12">
                	<?php if ($this->session->flashdata('S') == TRUE): ?>
                		<p><?= $this->session->flashdata('S'); ?></p>
                	<?php endif ?>
                	<div class="card">
                	<div class="card-header">
               			<h5><i class="fa fa-gear"></i> Semester</h5>
                	</div>
                	<div class="card-body">
                	<form action="<?= base_url('index.php')?>/Setting/proses_semester" method="post">
                		<?php foreach ($semester as $key): ?>
                		<input type="text" name="id" value="1" hidden="">
                		<div class="form-group">
                			<select class="form-control" name="semester">
                                <option>--> Pilih Semester <--</option>
                				<option value="semester 1">Semester 1</option>
                				<option value="semester 2">Semester 2</option>
                			</select>
                		</div>
	                		<div class="text-danger">Semester yang di gunakan saat ini: <?= $key->nama;?></div><br>
                		<?php endforeach ?>
                		<button class="btn btn-warning" name="Submit" type="submit" onclick="return confirm('Konfirmasi Pengaturan Semester')">Rubah Pengaturan</button>	
                	</form>
                	</div>
                	</div>
				</div>

                 <div class="col-md-12 col-sm-12 col-lg-12">
                    
                    <?php if ($this->session->flashdata('T')): ?>
                        <p><?= $this->session->flashdata('T');?></p>
                    <?php endif ?>
                    
                    <div class="card">
                    <div class="card-header">
                        <h5><i class="fa fa-gear"></i> Tahun Ajaran</h5>
                    </div>

                    <div class="card-body">
                    <form action="<?= base_url('index.php')?>/Setting/proses_ajaran" method="post">
                        
                        <input type="text" name="id" value="1" hidden="">
                        
                        <div class="form-group">
                            
                            <?php 
                                $date1 = date('Y');
                                $date2 = date('Y'); 
                            ?>
                            
                            <select class="form-control" name="tahun_ajaran">
                                <option>--> Pilih Tahun Pelajaran <--</option>
                                <?php foreach ($tahun as $key): ?>
                                  <option value="<?= $key->tahun_ajaran;?>"><?= $key->tahun_ajaran;?></option>
                                <?php endforeach; ?>
                            </select>

                        </div>
                        
                        <div class="text-danger">Tahun Ajaran yang di gunakan saat ini: 
                        <?php foreach ($ajaran as $key) :?>
                            <?= $key->nama;?>
                        <?php endforeach ?>
                        </div>
                        <br>
                        
                        <button class="btn btn-warning" name="Submit" type="submit" onclick="return confirm('Konfirmasi Pengaturan Tahun Ajaran')">Rubah Pengaturan</button>    

                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter" name="tahun_ajaran" type="submit">Tambah Tahun Ajaran Baru</button>
                    </form>
                    </div>
                    </div>
            </div>
            </div>
            </div>
 		</div>
	</div>
</div>

 <!-- modal medium -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true" style="margin-top: 15%;">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="">Tambah Tahun Ajaran Baru</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <form action="<?= base_url('index.php')?>/Setting/proses_ajaran" method="post" id="form">
                        <div class="row col-lg-12 col-md-12 col-sm-12">
                            <input type="text" name="id" value="1" hidden="">

                            <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                <label class="control-label mb-1">Tahun Ajaran Baru</label>
                                <input type="text" name="tahun_ajaran" class="form-control">
                                <p class="text-danger">*Format Tahun Ajaran Y/Y+1 <br>Contoh:2019/2020</p>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-lg btn-info btn-block" name="Submit">
                            <i class="fa fa-save"></i>&nbsp;
                            <span id="payment-button-amount">Simpan Tahun Ajaran Baru</span>
                        </button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- end modal medium -->