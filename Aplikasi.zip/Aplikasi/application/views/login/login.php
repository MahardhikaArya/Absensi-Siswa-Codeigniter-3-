    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                          <img src="<?php echo base_url(); ?>/assets/images/logo.png" alt="Absensi" width="50%">
                          <p class="text-center"><b>E-Abzen</b></p>
                        </div>
                        <!-- <?= password_hash("Juni", PASSWORD_DEFAULT, ['cost' => 10]) ?> -->
                        <div class="login-form">
                            <form action="<?= base_url('index.php')?>/login/aksi_login" method="post">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="username" placeholder="Username">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Masuk</button>
                            </form>
                            <div class="register-link">
                                    <label>
                                        <a href="<?= base_url('index.php'); ?>/login/lupa">Lupa Kata Sandi?</a>
                                    </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>