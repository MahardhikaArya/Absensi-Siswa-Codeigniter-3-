    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="images/icon/logo.png" alt="Absensi">
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="<?= base_url('index.php')?>/login/aksi_daftar" method="post">
                                <input type="text" name="level" value="admin" hidden="">
                                <div class="form-group">
                                    <label>Nama Lengkap</label>
                                    <input class="au-input au-input--full" type="text" name="NamaLengkap" placeholder="Nama Lengkap">
                                </div>
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="username" placeholder="Username">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                                </div>

                                <div class="form-group">
                                    <label>Kelas</label>
                                    <input class="au-input au-input--full" type="text" name="kelas" placeholder="kelas">
                                </div>

                                <div class="login-checkbox float-right">
                                    <label>
                                        <a href="#">Lupa Kata Sandi?</a>
                                    </label>
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Daftar</button>
                            </form>
                            <div class="register-link">
                                <p>
                                   Belum punya akun?
                                    <a href="#">Daftar sekarang</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>