    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                          <img src="<?php echo base_url(); ?>/assets/images/logo.png" alt="Absensi" width="50%">
                          <p class="text-center"><b>LUPA KATA SANDI ?</b></p>
                        </div>
                        <div class="login-form">
                            <div class="for-group text-center">
                                <p>Silahkan Hubungi : <a href=""><b>+0797989098989890</a></b></p>
                                <p>Atau</p>
                                <p>Temui Pak Effendi Untuk Reset Password</p>
                            </div>
                            <div class="register-link">
                                    <label>
                                        <a href="<?= base_url("index.php")?>/login">Login saja ?</a>
                                    </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>