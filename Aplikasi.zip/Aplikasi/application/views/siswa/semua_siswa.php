 <!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 col-lg-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="text-center">Semua siswa tahun Ajaran <?php echo $ajaran; ?></h4>
                </div>

                <div class="card-body table">

                <a href="<?= base_url('index.php')?>/Siswa/tambah_siswa" class="btn btn-primary m-b-10 float-right">
                  <button style="color:white;"><i class="fa fa-plus"></i> Tambah Siswa Baru</button>
                </a>

                <div class="table-responsive table--no-card m-b-40">
                    <table class="table table-borderless table-striped table-earning">
                      <thead>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Nis</th>
                        <th>Kelas</th>
<!--                         <th>Foto</th>  -->                     
                      </thead>
                      <tbody>
                        <?php $i=1; foreach ($siswa->result() as $key): ?>
                        <tr>
                          <td><?= $i++; ?></td>
                          <td><?= $key->nama; ?></td>
                          <td><?= $key->nis; ?></td>
                          <td><?= $key->kelas; ?></td>
                        </tr>
                        <?php endforeach ?>
                      </tbody>
                    </div>
                  </table>
                </div>
                </div>
              </div>
              </div>
            </div>
        </div>
     </div>
</div>