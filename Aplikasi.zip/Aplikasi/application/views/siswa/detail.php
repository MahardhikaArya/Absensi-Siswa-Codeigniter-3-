 <!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 col-lg-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="text-center"><?= $nama;?></h4>
                </div>
                <div class="card-body">
                  <div class="form-group text-center">
                  <img src="<?php echo base_url() ?>/assets/images/icon/avatar-01.jpg" class="img img-thumbnail">
                  </div>
                  
                  <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="" name="" class="form-control" value="<?php echo $nama; ?>">
                  </div>

                  <div class="form-group">
                    <label>Alamat</label>
                    <input type="" name="" class="form-control" value="<?php echo $alamat; ?>">
                  </div>

                  <div class="form-group">
                    <label>Telepon</label>
                    <input type="" name="" class="form-control" value="<?php echo $telepon; ?>">
                  </div>

                  <div class="form-group">
                    <label>Kelas</label>
                    <input type="" name="" class="form-control" value="<?php echo $kelas; ?>">
                  </div>

                  <div class="form-group">
                    <label>Nis</label>
                    <input type="" name="" class="form-control" value="<?php echo $nis; ?>">
                  </div>

                  <div class="form-group">
                    <label>nisn</label>
                    <input type="" name="" class="form-control" value="<?php echo $nisn; ?>">
                  </div>

                  <div class="form-group">
                    <label>Siswa Tahun Ajaran</label>
                    <input type="" name="" class="form-control" value="<?php echo $tahun_ajaran; ?>">
                  </div>

                  <div class="form-group">
                    <label>Siswa Alumni Tahun</label>
                    <input type="" name="" class="form-control" value="<?php echo $siswa_tahun; ?>">
                  </div>

                  <div class="form-group">
                    <label>Agama</label>
                    <input type="" name="" class="form-control" value="<?php echo $agama; ?>">
                  </div>

                  <div class="form-group">
                    <label>Status</label>
                    <input type="" name="" class="form-control" value="<?php echo $status; ?>">
                  </div>

                  <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="" name="" class="form-control" value="<?php echo $nama_ayah; ?>">
                  </div>

                  <div class="form-group">
                    <label>Nomor Ayah</label>
                    <input type="" name="" class="form-control" value="<?php echo $no_ayah; ?>">
                  </div>

                  <div class="form-group">
                    <label>Alamat Ayah</label>
                    <input type="" name="" class="form-control" value="<?php echo $alamat_ayah; ?>">
                  </div>

                  <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="" name="" class="form-control" value="<?php echo $nama_ibu; ?>">
                  </div>

                  <div class="form-group">
                    <label>Nomor Ibu</label>
                    <input type="" name="" class="form-control" value="<?php echo $no_ibu; ?>">
                  </div>

                  <div class="form-group">
                    <label>Alamat Ibu</label>
                    <input type="" name="" class="form-control" value="<?php echo $alamat_ibu; ?>">
                  </div>

                </div>
              </div>
              </div>
            </div>
        </div>
     </div>
</div>