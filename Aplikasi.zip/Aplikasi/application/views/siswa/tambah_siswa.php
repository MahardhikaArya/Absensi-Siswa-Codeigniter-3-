<script type="text/javascript">

function previewImage() {
    document.getElementById("image-preview").style.display = "block";
    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image-source").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("image-preview").src = oFREvent.target.result;
    };
  };  
</script>
 <!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 col-lg-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="text-center">Tambah Siswa Baru</h4>
                </div>
                <div class="card-body">
                  <form action="<?= base_url('index.php')?>/Siswa/proses_insert" method="post" role="form" enctype="multipart/form-data">

			 	  <div class="form-group">
	                <img id="image-preview" alt="image preview">
	                <label>Pilih Gambar Siswa</label><br>
	                <input class="btn btn-warning" style="color:white;" type="file" required="" name="gambar" id="image-source" onchange="previewImage();">
	              </div>
                  
                  <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="" name="nama" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Alamat</label>
                    <input type="" name="alamat" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Telepon</label>
                    <input type="" name="telepon" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Kelas</label>
                    <input type="" name="kelas" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Nis</label>
                    <input type="" name="nis" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>nisn</label>
                    <input type="" name="nisn" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Siswa Tahun Ajaran</label>
                    <input type="" name="tahun_ajaran" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Siswa Alumni Tahun</label>
                    <input type="" name="siswa_tahun" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Agama</label>
                    <input type="" name="agama" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Status</label>
                    <input type="" name="status" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Nama Ayah</label>
                    <input type="" name="nama_ayah" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Nomor Ayah</label>
                    <input type="" name="no_ayah" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Alamat Ayah</label>
                    <input type="" name="alamat_ayah" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Nama Ibu</label>
                    <input type="" name="nama_ibu" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Nomor Ibu</label>
                    <input type="" name="no_ibu" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Alamat Ibu</label>
                    <input type="" name="alamat_ibu" class="form-control">
                  </div>

				<button type="submit" class="btn btn-primary">Simpan Data</button>
				<button type="reset" class="btn btn-warning">Reset Form</button>
				<button onclick="window.history(-1)" class="btn btn-default">Kembali</button>
			</form>

                </div>
              </div>
              </div>
            </div>
        </div>
     </div>
</div>