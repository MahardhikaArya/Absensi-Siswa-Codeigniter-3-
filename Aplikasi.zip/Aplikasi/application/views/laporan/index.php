<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="text-center">Laporan kelas <?= $this->session->userdata('kelas');?></h2>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <hr>
                                <p class="title-3">Rekapan Singkat</p>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Alpha</th>
                                                <th>Dispen</th>
                                                <th>Sakit</th>
                                                <th>Izin</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><?php foreach ($alpha->result() as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($dispen->result() as $key) {
                                                echo $key->data;
                                            } ?></td>                                            
                                            <td><?php foreach ($sakit->result() as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($ijin->result() as $key) {
                                                echo $key->data;
                                            } ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <hr>
                                <p class="title-3">Detail Rekapan Absen</p>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nis / Nama</th>
                                                <th>Keterangan</th>
                                                <th>Tanggal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=1; foreach ($detail as $key): ?>
                                            <tr>
                                                <td><?= $i++;  ?></td>
                                                <td><?= $key->nama;?></td>
                                                <td><?= $key->keterangan;?></td>
                                                <td><?= $key->tanggal;?></td>
                                            </tr>
                                            <?php endforeach ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->