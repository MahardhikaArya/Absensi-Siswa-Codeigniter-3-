<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <p class="text-success">
                                    <?php foreach ($semester as $key): ?>
                                        <?php echo $key->nama; ?>
                                    <?php endforeach ?>
                                        
                                    </p>
                                    <h2 class="title-1">Laporan kelas <?= $this->session->userdata('kelas');?></h2>
                                    <p class="text-success">
                                        tahun ajaran
                                        <?php foreach ($tahun_ajaran as $key): ?>
                                            <?php echo strtoupper($key->nama); ?>
                                        <?php endforeach ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <hr>
                                <p class="title-3">Rekapan Singkat</p>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Alpha</th>
                                                <th>Dispen</th>
                                                <th>Sakit</th>
                                                <th>Izin</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><?php foreach ($alpha as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($dispen as $key) {
                                                echo $key->data;
                                            } ?></td>                                            
                                            <td><?php foreach ($sakit as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($ijin as $key) {
                                                echo $key->data;
                                            } ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <hr>

                                <div class="float-left">
                                    <p class="title-3 ">Detail Rekapan Absen </p>
                                    </p>
                                </div>

                                <div class="float-right">
                                    <a href="<?= base_url("index.php");?>/Laporan/print" target="_blank">
                                        <button class="btn btn-warning">Cetak Laporan</button>
                                    </a>

                                    <a href="<?= base_url("index.php");?>/Laporan/excel" target="_blank">
                                        <button class="btn btn-success">Unduh Excel</button>
                                    </a>
                                </div>

                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nis / Nama</th>
                                                <th>Keterangan</th>
                                                <th>Catatan</th>
                                                <th>Tanggal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($detail->num_rows() > 0): ?>
                                            <?php $i=1; foreach ($detail->result() as $key): ?>
                                            <tr>
                                                <td><?= $i++;  ?></td>
                                                <td><?= $key->nama;?></td>
                                                <td><?= $key->keterangan;?></td>
                                                <td><?= $key->catatan;?></td>
                                                <td><?= $key->tanggal;?></td>
                                            </tr>
                                            <?php endforeach ?>
                                            <?php endif ?>

                                            <?php if ($detail->num_rows() == 0): ?>
                                                <h1 class="">NIHIL SEPENUHNYA</h1>
                                            <?php endif ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MAIN CONTENT-->