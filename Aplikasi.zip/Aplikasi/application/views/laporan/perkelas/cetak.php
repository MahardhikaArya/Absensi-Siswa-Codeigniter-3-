<?php 
                                $date1 = date('Y');
                                $date2 = date('Y');
                             ?>
                            <div class="col-lg-12">
                                <hr>
                                <h3 class="text-center">Rekapan Abensi kelas <?= $this->session->userdata('kelas');?><br>
                                 tahun pelajaran <?= $date1;?>/<?= $date2+1;?> <br>
                                 <?php foreach ($ster as $k): ?>
                                  <?= $k->nama; ?>
                                 <?php endforeach ?>                                 
                                </h3>                                 
                                <p style="margin-top: 10px;margin-bottom: 10px;">Nama Walikelas : <?= $this->session->userdata('nama');?></p>
                                <?php if ($detail->num_rows() > 0): ?> 
                                <div class="table-responsive table--no-card m-b-40">                                    
                                    <table class="table table-borderlesss">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nis / Nama</th>
                                                <th>Keterangan</th>
                                                <th>Tanggal</th>
                                                <th>Catatan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i=1; foreach ($detail->result() as $key): ?>
                                            <tr>
                                                <td><?= $i++;  ?></td>
                                                <td><?= $key->nama;?></td>
                                                <td><?= $key->keterangan;?></td>
                                                <td><?= $key->tanggal;?></td>
                                                <td><?= $key->catatan;?></td>
                                            </tr>
                                            <?php endforeach ?>

                                        </tbody>

                                    </table>
                                </div>
                                    <?php endif ?>
                                    <?php if ($detail->num_rows() == 0): ?>
                                        <h3>KELAS <?= $this->session->userdata('kelas'); ?> NIHIL SEPENUHNYA</h3>
                                    <?php endif ?>
                            </div>

                            <hr>

                           <?php if ($detail->num_rows() > 0): ?> 
                            <div class="col-lg-12">
                                <hr>
                                <p class="title-3">Ringkasan Rekapan</p>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Alpha</th>
                                                <th>Dispen</th>
                                                <th>Sakit</th>
                                                <th>Izin</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><?php foreach ($alpha as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($dispen as $key) {
                                                echo $key->data;
                                            } ?></td>                                            
                                            <td><?php foreach ($sakit as $key) {
                                                echo $key->data;
                                            } ?></td>
                                            <td><?php foreach ($ijin as $key) {
                                                echo $key->data;
                                            } ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php endif ?>
                            <?php if ($detail->num_rows() == 0): ?> 
                                <p></p>
                            <?php endif ?>
                            <p class="text-right">Laporan ini dicetak pada : <?= date('d-m-Y');  ?></p>
                            <script type="text/javascript">
                                window.print();
                            </script>

    <title>Dashboard</title>

    <!-- Fontfaces CSS-->
    <link href="<?= base_url();?>/assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?= base_url();?>/assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?= base_url();?>/assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="<?= base_url();?>/assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?= base_url();?>/assets/css/theme.css" rel="stylesheet" media="all">                            
        <!-- Jquery JS-->
    <script src="<?= base_url();?>/assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="<?= base_url();?>/assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="<?= base_url();?>/assets/vendor/slick/slick.min.js">
    </script>
    <script src="<?= base_url();?>/assets/vendor/wow/wow.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/animsition/animsition.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="<?= base_url();?>/assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="<?= base_url();?>/assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="<?= base_url();?>/assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="<?= base_url();?>/assets/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="<?= base_url()?>/assets/js/main.js"></script>
