<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dev extends CI_Model {
	public function __construct(){
		parent::__construct();
	}

	function count($table){
		return $this->db->count_all($table);
	}

	function count_where($table, $where){
		$this->db->from($table);
		$this->db->where($where);

		return $this->db->count_all_resultS();
	}
	function delete($table, $where)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}

	function update($table = null, $data = null, $where = null)
	{
		$this->db->update($table, $data, $where);
	}

	//Count Laporan 
	function count_ijin($where1, $where2)
	{
		$w = $this->session->userdata('kelas');
		$q = $this->db->query("select count(keterangan) as data from tb_absen where kelas = '$w' and keterangan = 'ijin' and semester = '$where1' and tahun_ajaran = '$where2' ");
		return $q->result();
	}
	
	function count_alpha($where1, $where2)
	{
		$w = $this->session->userdata('kelas');
		$q = $this->db->query("select count(keterangan) as data from tb_absen where kelas = '$w' and keterangan = 'alpha' and semester = '$where1' and tahun_ajaran = '$where2' ");
		return $q->result();
	}
	
	function count_dispen($where1, $where2)
	{
		$w = $this->session->userdata('kelas');
		$q = $this->db->query("select count(keterangan) as data from tb_absen where kelas = '$w' and keterangan = 'dispen' and semester = '$where1' and tahun_ajaran = '$where2'");
		return $q->result();
	}
	function count_sakit($where1, $where2)
	{
		$w = $this->session->userdata('kelas');
		$q = $this->db->query("select count(keterangan) as data from tb_absen where kelas = '$w' and keterangan = 'sakit' and semester = '$where1' and tahun_ajaran = '$where2'");
		return $q->result();
	}

	function get_nis_absensi($where)
	{
		$q = $this->db->query("select nis from tb_siswa where nama = '$where'");
		return $q;
	}

	function get_data($table)
	{
		$this->db->from($table);
		$q = $this->db->get();
		return $q->result();
	}

	function get_all_laporan($table, $where1, $where2)
	{
		$w = $this->session->userdata('kelas');
		$this->db->from($table);
		$this->db->order_by('nama');
		$this->db->where($where1);
		$this->db->where($where2);
		$this->db->where("kelas = '$w'");
		$q = $this->db->get();
		return $q;
	}

	function get_kelas(){
		$q = $this->db->query("select kelas,count(nama) as data from tb_siswa group by kelas");
		return $q;
	}

	function get_tahun(){
		$q = $this->db->query("select tahun_ajaran from tb_absen group by tahun_ajaran;");
		return $q->result();
	}

	function insert($table, $data)
	{
		$this->db->insert($table, $data);
	}

	function get_where($table, $where)			
	{
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->get();
	}

	function get_where2($table, $where1, $where2)			
	{
		$this->db->from($table);
		$this->db->where($where1);
		$this->db->where($where2);
		return $this->db->get();
	}

	function get_absensi_desc($table, $where1, $where2, $where3)			
	{
		$this->db->from($table);
		$this->db->where($where1);
		$this->db->where($where2);
		$this->db->where($where3);
		$this->db->order_by('tanggal Desc');
		return $this->db->get();
	}

	function get_where3($table, $where1, $where2, $where3)			
	{
		$this->db->from($table);
		$this->db->where($where1);
		$this->db->where($where2);
		$this->db->where($where3);
		return $this->db->get();
	}

	function get_where4($table, $where1, $where2, $where3, $where4)			
	{
		$this->db->from($table);
		$this->db->where($where1);
		$this->db->where($where2);
		$this->db->where($where3);
		$this->db->where($where4);
		return $this->db->get();
	}




	function absen_kini($where){
		$date = date('Y-m-d');
		$kelas = $this->session->userdata('kelas');
		$w = $this->db->query("select * from tb_absen where tanggal = '$date' and kelas = '$kelas' and tahun_ajaran = '$where'");
		return $w;
	} 


}
