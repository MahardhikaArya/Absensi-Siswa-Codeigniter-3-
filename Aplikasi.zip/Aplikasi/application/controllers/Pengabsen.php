<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengabsen extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('Template');
	}
	
	public function index()
	{
		$data['admin'] = $this->dev->get_where('tb_admin', ['level' => 'pengabsen']);
		$data['admins'] = $this->dev->get_where('tb_admin', ['level' => 'admin']);
		$this->template->admin('admin/super_admin/pengabsen/index', $data);
	}

	
	
}
