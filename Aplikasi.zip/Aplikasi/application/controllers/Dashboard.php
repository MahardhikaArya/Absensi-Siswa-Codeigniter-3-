<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('Template');
	}
	
	public function index()
	{
		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$data['siswa'] = $this->dev->count_where('tb_siswa', ['kelas' => $this->session->userdata('kelas')]);
		$data['absen'] = $this->dev->count_where('tb_absen', ['keterangan' => null]);
		$data['siswas'] = $this->dev->get_where('tb_siswa', ['kelas' => $this->session->userdata('kelas')]);
		$tanggal = date('Y-m-d');
		$data['home'] = $this->dev->absen_kini($thn);
		$data['tahun'] = $this->dev->get_data('tb_tahun');

		// Get Data Today
		$data['hari_ini'] = $this->dev->get_where2('tb_absen', ['kelas' => $this->session->userdata('kelas')], ['tanggal' => date('Y-m-d')]);

		// Ambil data Semeter
		$data['semester'] = $this->dev->get_data('tb_pengaturan');

		// Ambil data tahun ajaran
		$data['tahun_ajaran'] = $this->dev->get_data('tb_tahun');

		$this->template->admin('admin/home', $data);
	}

	public function tambah()
	{
		$nis = $this->dev->get_nis_absensi($this->input->post('nama'));
		
		foreach ($nis->result() as $k) {
			$data_nis = $k->nis;
		}
		
		$data = array(
			'id'		   => $this->input->post('id', TRUE),
			'kelas' 	   => $this->input->post('kelas', TRUE),
			'tanggal' 	   => $this->input->post('tanggal', TRUE),
			'nama' 	       => $this->input->post('nama', TRUE),
			'nis' 	       => $data_nis,
			'catatan' 	   => $this->input->post('catatan', TRUE),
			'semester'	   => $this->input->post('semester', TRUE),
			'tahun_ajaran' => $this->input->post('tahun_ajaran', TRUE),
			'keterangan'   => $this->input->post('keterangan', TRUE)
		);

		$this->dev->insert('tb_absen', $data);
		$this->session->set_flashdata('berhasil','Data Berhasil Di input');
		redirect('Dashboard');
	}

	public function admin()
	{
		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$data['siswa'] = $this->dev->count_where('tb_siswa', ['kelas' => $this->session->userdata('kelas')]);
		$data['absen'] = $this->dev->count_where('tb_absen', ['keterangan' => null]);
		$tanggal = date('Y-m-d');
		$data['home'] = $this->dev->absen_kini($thn);
		$this->template->admin('admin/super_admin/index', $data);
	}


	

}
