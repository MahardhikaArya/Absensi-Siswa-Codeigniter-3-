<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kelas extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('Template');
	}
	
	public function index()
	{
		$data['admin'] = $this->dev->get_kelas();
		$tahun_ajaran = $this->dev->get_data('tb_tahun');

		foreach ($tahun_ajaran as $key) {
			$data['tahun_ajaran'] = $key->nama;
		}

		$this->template->admin('admin/super_admin/kelas/index', $data);
	}

	public function Detail_kelas()
	{
		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$uri = $this->uri->segment(3);
		$data['admin'] = $this->dev->get_where2('tb_siswa', ['kelas' => $uri], ['tahun_ajaran' => $thn]);
		$this->template->admin('admin/super_admin/kelas/detail_kelas', $data);
	}
	
	
}
