<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('Template');
	}

	public function index()
	{
		$this->template->login('login/login');
	}

	public function daftar()
	{
		$this->template->login('login/signup');
	}	

	public function lupa()
	{
		$this->template->login('login/forgot');
	}

	public function aksi_daftar()
	{
		$data['username'] 	 = $this->input->post('username', TRUE);
		$data['NamaLengkap'] = $this->input->post('NamaLengkap', TRUE);
		$pass		  	  	 = $this->input->post('password', TRUE);
		$data['level']	  	 = $this->input->post('level', TRUE);
		$data['password'] 	 = password_hash($pass, PASSWORD_DEFAULT, ['cost' => 10]);
		$this->dev->insert('tb_admin', $data);	
		echo "Akun berhasil di buat";
	}

	public function aksi_login()
	{
		$user = $this->input->post('username', TRUE);
		$pass = $this->input->post('password', TRUE);
		$cek = $this->dev->get_where('tb_admin', array('username' => $user));
		if ($cek->num_rows() > 0) {
			$data = $cek->row();
			if (password_verify($pass, $data->password)) {
				$datauser = array(
					'admin' => $data->id,
					'level' => $data->level,
					'kelas' => $data->kelas,
					'nama'  => $data->NamaLengkap,
					'user'  => $data->username,
					'login' => TRUE
				);

				$this->session->set_userdata($datauser);
				if ($this->session->userdata('level') == 'pengabsen') {
					redirect('dashboard');
				}elseif ($this->session->userdata('level') == 'admin') {
					redirect('dashboard/admin');
				}else{
					echo "Internal Error !!! ,Contact Develope";
				}
			}else{echo "password salah!!!";}
			}else{echo "kesalahan akun!!!";}

		if ($this->session->userdata('login') == TRUE) {
			if ($this->session->userdata('level') == 'pengabsen') {
				redirect('dashboard');
			}elseif ($this->session->userdata('level') == 'admin') {
				redirect('dashboard_admin');
			}else{
				echo "Internal Error !!! ,Contact Develope";
			}
		}

	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}
