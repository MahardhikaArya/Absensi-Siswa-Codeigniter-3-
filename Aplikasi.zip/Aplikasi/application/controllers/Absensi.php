<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absensi extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('template');
	}

	public function index()
	{
		$semester = $this->dev->get_data('tb_pengaturan');
		foreach ($semester as $k) {
			$sem = $k->nama;
		}

		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}
		
		// Rekap Sekilas
		$data['ijin'] 		= $this->dev->count_ijin($sem, $thn);
		$data['dispen'] 	= $this->dev->count_dispen($sem, $thn);
		$data['sakit'] 		= $this->dev->count_sakit($sem, $thn);
		$data['alpha'] 		= $this->dev->count_alpha($sem, $thn);

		$data['nama']  = $this->dev->get_where('tb_siswa', ['kelas' => $this->session->userdata('kelas')]);	

		// Query Absensi
		$data['absen'] = $this->dev->get_absensi_desc('tb_absen', ['kelas' => $this->session->userdata('kelas')], ['semester' => $sem], ['tahun_ajaran' => $thn]);		

		// Ambil data Semeter
		$data['semester'] = $this->dev->get_data('tb_pengaturan');

		// Ambil data tahun ajaran
		$data['tahun_ajaran'] = $this->dev->get_data('tb_tahun');
		
		$this->template->admin('absensi/index', $data);

	}

	public function tambah()
	{
		$nis = $this->dev->get_nis_absensi($this->input->post('nama'));
		
		foreach ($nis->result() as $k) {
			$data_nis = $k->nis;
		}
		
		$data = array(
			'id'		   => $this->input->post('id', TRUE),
			'kelas' 	   => $this->input->post('kelas', TRUE),
			'tanggal' 	   => $this->input->post('tanggal', TRUE),
			'nama' 	       => $this->input->post('nama', TRUE),
			'nis' 	       => $data_nis,
			'catatan' 	   => $this->input->post('catatan', TRUE),
			'semester'	   => $this->input->post('semester', TRUE),
			'tahun_ajaran' => $this->input->post('tahun_ajaran', TRUE),
			'keterangan'   => $this->input->post('keterangan', TRUE)
		);

		$this->dev->insert('tb_absen', $data);
		redirect('Absensi');
	}

	public function edit()
	{
		$semester = $this->dev->get_data('tb_pengaturan');
		foreach ($semester as $k) {
			$sem = $k->nama;
		}

		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		// Query Absensi
		$edit = $this->dev->get_where('tb_absen', ['id' => $this->uri->segment(3)]);

		foreach ($edit->result() as $key) {
			$data['id'] 		= $key->id;
			$data['nama'] 		= $key->nama;
			$data['keterangan'] = $key->keterangan;
			$data['catatan']    = $key->catatan;
		}
		
		$this->template->admin('absensi/edit', $data);
	}

	public function proses_edit()
	{	

		$data = array(
			'nama' 		=> $this->input->post('nama',TRUE),
			'keterangan'=> $this->input->post('keterangan', TRUE),
			'catatan' 	=> $this->input->post('catatan', TRUE)
		);

		$cond = array('id' => $this->uri->segment(3));
		$this->dev->update('tb_absen', $data, $cond);

		$this->session->set_flashdata('S', 'Data Berhasil Diubah');
		redirect('absensi');
	}

	public function hapus()
	{
		$this->dev->delete('tb_absen', ['id' => $this->uri->segment(3)]);
		redirect('Absensi');
	}

}
