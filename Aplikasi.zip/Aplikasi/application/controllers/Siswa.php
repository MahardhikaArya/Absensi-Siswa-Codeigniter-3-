<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('template');
	}

	public function index()
	{

		//Insert Siswa
		$data['siswa'] 		= $this->dev->get_where('tb_siswa', ['kelas' => $this->session->userdata('kelas')]);
		$this->template->admin('siswa/index', $data);
	}

	public function Semua_siswa()
	{
		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $key) {
			$ajaran = $key->nama;
		}
		$data['ajaran'] = $ajaran;
		$data['siswa'] = $this->dev->get_where('tb_siswa', ['tahun_ajaran' => $ajaran]);
		$this->template->admin('siswa/Semua_siswa', $data);
	}

	public function Detail_siswa()
	{
		$siswa = $this->dev->get_where('tb_siswa', ['id' => $this->uri->segment(3)]);
		foreach ($siswa->result() as $key) {
			$data['nama']  			= $key->nama;
			$data['alamat']			= $key->alamat;
			$data['telepon']		= $key->telepon;
			$data['kelas']			= $key->kelas;
			$data['nis']			= $key->nis;
			$data['nisn']			= $key->nisn;
			$data['tahun_ajaran']	= $key->tahun_ajaran;
			$data['siswa_tahun']	= $key->siswa_tahun;			
			$data['nama_ayah']		= $key->nama_ayah;
			$data['nama_ibu']		= $key->nama_ibu;
			$data['no_ibu']			= $key->no_ibu;
			$data['no_ayah']		= $key->no_ayah;
			$data['alamat_ibu']		= $key->alamat_ibu;
			$data['alamat_ayah']	= $key->alamat_ayah;
			$data['agama']			= $key->agama;
			$data['status']			= $key->status;
		}

		$this->template->admin('siswa/detail', $data);
	}
	
	public function tambah_siswa()
	{
		$this->template->admin('siswa/tambah_siswa');	
	}

	public function proses_insert()
	{
		 $config['upload_path'] = './assets/upload/';
		 $config['allowed_types'] = 'jpg|png|jpeg';
		 $config['max_size'] = '2048';
		 $config['file_name'] = 'Siswa'.$this->input->post('nis');

		 $this->load->library('upload', $config);
		 if ($this->upload->do_upload('gambar')){
 		    $gbr = $this->upload->data();
			$data = array(
				'nama' 		=> $this->input->post('nama'),
				'nis' 		=> $this->input->post('nis'),
				'kelas' 	=> $this->input->post('kelas'),
				'telepon' 	=> $this->input->post('telepon'),
			    'foto' 		=> $gbr['file_name'],
				'alamat' 	=> $this->input->post('alamat')
			);
			$this->dev->insert('tb_siswa', $data);
			$this->session->set_flashdata('berhasil','Data Berhasil Di tambah !!!');
			redirect('siswa');
		}

		else{
			echo $this->upload->display_errors();
		}

	}

}
