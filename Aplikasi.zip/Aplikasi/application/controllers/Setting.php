<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('dev');
		$this->load->library('template');
	}

	public function index()
	{
		$data['semester'] = $this->dev->get_data('tb_pengaturan');
		$data['ajaran']	  = $this->dev->get_data('tb_tahun');
		$data['tahun'] 	  = $this->dev->get_tahun();
		$this->template->admin('pengaturan/index', $data);
	}

	public function proses_semester()
	{
		$data = array(
			'id' => $this->input->post('id', TRUE),
			'nama' => $this->input->post('semester', TRUE)
		);

		$this->dev->update('tb_pengaturan', array('id' => $this->input->post('id')), $data);
		$this->session->set_flashdata('S', 'Semester Berhasil Dirubah');
		redirect('Setting');
	}

	public function proses_ajaran()
	{
		$data = array(
			'id' => $this->input->post('id', TRUE),
			'nama' => $this->input->post('tahun_ajaran', TRUE)
		);

		$this->dev->update('tb_tahun', array('id' => $this->input->post('id')), $data);
		$this->session->set_flashdata('T', 'Tahun Ajaran Berhasil Dirubah');
		redirect('Setting');
	}

}
