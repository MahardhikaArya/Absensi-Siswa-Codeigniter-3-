<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('dev');
		$this->load->library('Template');
	}

	public function index()
	{
		$semester = $this->dev->get_data('tb_pengaturan');
		foreach ($semester as $k) {
			$sem = $k->nama;
		}

		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$data['tahun_ajaran'] = $this->dev->get_data('tb_tahun');
		$data['semester'] = $this->dev->get_data('tb_pengaturan');
		$data['kelas'] 	= $this->dev->get_data('tb_kelas');

		$data['ijin'] 	= $this->dev->count_ijin($sem, $thn);
		$data['dispen'] = $this->dev->count_dispen($sem, $thn);
		$data['sakit'] 	= $this->dev->count_sakit($sem, $thn);
		$data['alpha']  = $this->dev->count_alpha($sem, $thn);
		
		$data['detail'] = $this->dev->get_all_laporan('tb_absen', ['semester' => $sem], ['tahun_ajaran' => $thn]);

		$this->template->admin('laporan/perkelas/index.php', $data);
	}


	public function print()
	{
		$semester = $this->dev->get_data('tb_pengaturan');
		foreach ($semester as $k) {
			$sem = $k->nama;
		}
		
		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$data['ster'] 	= $this->dev->get_data('tb_pengaturan');
		$data['kelas'] 		= $this->dev->get_data('tb_kelas');
		$data['ijin'] 		= $this->dev->count_ijin($sem, $thn);
		$data['dispen'] 		= $this->dev->count_dispen($sem, $thn);
		$data['sakit'] 		= $this->dev->count_sakit($sem, $thn);
		$data['alpha'] 		= $this->dev->count_alpha($sem, $thn);

		$data['detail'] = $this->dev->get_all_laporan('tb_absen', ['semester' => $sem], ['tahun_ajaran' => $thn]);
		$this->load->view('laporan/perkelas/cetak.php', $data);
	}

	public function excel()
	{
		$semester = $this->dev->get_data('tb_pengaturan');
		foreach ($semester as $k) {
			$sem = $k->nama;
		}

		$tahun = $this->dev->get_data('tb_tahun');
		foreach ($tahun as $ke) {
			$thn = $ke->nama;
		}

		$data['kelas'] 		= $this->dev->get_data('tb_kelas');
		$data['ijin'] 		= $this->dev->count_ijin($sem, $thn);
		$data['dispen'] 		= $this->dev->count_dispen($sem, $thn);
		$data['sakit'] 		= $this->dev->count_sakit($sem, $thn);
		$data['alpha'] 		= $this->dev->count_alpha($sem, $thn);

		$absen =  $this->dev->get_all_laporan('tb_absen', ['semester' => $sem], ['tahun_ajaran' => $thn]);
	
		$this->load->view('laporan/perkelas/excel', $data);	
	}

	public function admin()
	{
		$data['admin'] = $this->dev->get_kelas('tb_kelas');
		$this->template->admin('admin/super_admin/laporan/index', $data);
	}
}

